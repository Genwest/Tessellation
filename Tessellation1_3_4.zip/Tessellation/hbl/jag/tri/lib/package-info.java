/**
 * This package contains the triangle tessellation classes
 * that are used in the DagTri formulation
 */
/**
 * @author jag
 *
 */
package hbl.jag.tri.lib;