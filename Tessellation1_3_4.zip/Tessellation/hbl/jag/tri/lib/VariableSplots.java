package hbl.jag.tri.lib;

/**
 * place holder for futuure development
 * @author jag
 *
 */

public interface VariableSplots {
	// adds method to merge the mass of two splots
	Double AddSplotMasses(int indexS1,int indexS2);	
}